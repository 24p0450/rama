package Projectt;
import com.example.gui1.AdminGui.Birthdate;

import java.util.ArrayList;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.Random;

public class Admin extends Person{
    private String role;
    private Gender gender;
    private boolean[] workinghours = new boolean[24];
    private int workinghourscount;
    int choice;

    Birthdate birthdate = new Birthdate();
    //Constructors
    public Admin(){}
    public Admin(String dateofbirth,String role,boolean[] workinghours,String username,String password,Gender gender)
    {
        super(username,password);
        birthdate.setDateofbirth(dateofbirth);
        this.workinghours=workinghours;
        for (int i = 0; i < workinghours.length;i++){
            if (workinghours[i]){
                workinghourscount++;
            }
        }
        this.role = role;
        this.gender=gender;
    }
    //Overriden methods
    @Override
    public String toString()
    {
        StringBuilder string;
        string = new StringBuilder("Admin username: " + super.getUsername() + "\nRole: " + role + "\nBirthdate: " + birthdate.getDateofbirth() + "\nWorking hours: ");
        for (int i = 0; i < 24; i ++)
        {
            if (workinghours[i])
            {
                if (i <10)
                    string.append("0").append(i).append(":00 ");
                else
                    string.append(i).append(":00 ");
            }
        }
        string.append("\nTotal work hours: ").append(workinghourscount);
        return string.toString();
    }
    @Override
    public boolean equals(Object obj){
        if (this == obj)
            return true;
        if (!(obj instanceof Admin))
            return false;
        Admin other = (Admin) obj;
        if (super.getUsername() != null && other.getUsername() != null) {
            return super.getUsername().equals(other.getUsername());
        }
        else
        {
            System.out.println("Error⛔ : The username value null.");
            return false;
        }
    }

    //Role setter and getter
    public void setRole(String text) {
//        String role="";
//        System.out.println("Enter the new role: ");
//        role = scanner.nextLine();
//        if (role != null && !role.isBlank()) {
//            this.role = role;
//            System.out.println("You have set your role successfully✅ ");
//        }
//        else
//            System.out.println("Error⛔ : Role can not be null or blank❗");
        role=text;
    }
    public String getRole() {
        if (role != null) {
            return role;
        }
        else
            return "Invalid output❌. Role value is null";
    }

    //Working hours getter and setter
    public void setWorkinghours()
    {
        System.out.println("For the next hours,type 'yes' to mark it as working");
        workinghourscount = 0;
        scanner.nextLine();
        for (int i = 0; i < 24; i ++)
        {
            if (i <10)
                System.out.print("0"+i+":00 : ");
            else
                System.out.print(i+":00 : ");
            if (scanner.nextLine().equalsIgnoreCase("Yes"))
            {
                workinghours[i] = true;
                workinghourscount++;
            }
            else
                workinghours[i] = false;
        }
        System.out.println("You have changed your working hours successfully✅");
    }

    public void setWorkinghoursarray(boolean[] hours){
        this.workinghours = hours;
    }
    public boolean[] getWorkinghours() {
        return workinghours;
    }




    Random random = new Random();

    public void setWorkinghoursrandom()
    {
        workinghourscount = 0;
        for (int i = 0; i < 24; i++)
        {
            workinghours[i] = random.nextBoolean();
            if (workinghours[i])
                workinghourscount++;
        }
        System.out.println("You have set your working hours successfully✅ ");
    }

    public String getWorkinghoursoutput()
    {
        StringBuilder hours = new StringBuilder();
        hours.setLength(0);
        int counter = 0;
        for (int i = 0; i < 24; i ++)
        {
            if (workinghours[i])
            {
                if (counter%4 == 0 && counter != 0){
                    counter = 0;
                    hours.append('\n');
                }
                if (i <10)
                    hours.append("0").append(i).append(":00 ");
                else
                    hours.append(i).append(":00 ");
                counter++;
            }
        }
        return hours.toString();
    }

    public int getWorkinghourscount() {
        return workinghourscount;
    }

    public void showoptions(){
        System.out.println("🎩 Admin Menu 🎩");
        System.out.println("⿡  View Profile");
        System.out.println("⿢  Edit Password");
        System.out.println("⿣  Set Working Hours");
        System.out.println("⿤  Edit role");
        System.out.println("⿥  Edit username");
        System.out.println("⿦  Edit Date of Birth");
        System.out.println("⿧  Manage Rooms");
        System.out.println("⿨  Show all");
        System.out.println("⿩  Manage Categories");
        System.out.println("\uD83D\uDD1F   Logout 🚪");
    }

    public int checkchoice1()
    {
        int choice = 0;
        boolean choicevalid = false;
        do {
            try {
                System.out.print("Enter your choice: ");
                choice = scanner.nextInt();
                if (choice < 1 || choice > 10) {
                    System.out.println("Invalid number❌,enter 1-10.");
                } else
                    choicevalid = true;
            } catch (NumberFormatException e) {
                System.out.println("Invalid format❌.");
                scanner.nextLine();
            }
            catch (InputMismatchException e){
                System.out.println("Invalid format❌.");
                scanner.nextLine();
            }
        }while(!choicevalid);
        return choice;
    }

    public int showmanageRoom()
    {
        int choice = 0;
        boolean choicevalid = false;
        System.out.println("🎩 Manage Rooms 🎩");
        System.out.println("⿡  Add Room");
        System.out.println("⿢  Delete Room");
        scanner.nextLine();
        do {
            try {
                System.out.print("Enter your choice: ");
                choice = scanner.nextInt();
                if (choice < 1 || choice > 2) {
                    System.out.println("Invalid number❌,enter 1-2.");
                } else
                    choicevalid = true;
            } catch (NumberFormatException e) {
                System.out.println("Invalid format❌.");
                scanner.nextLine();
            }
            catch (InputMismatchException e){
                System.out.println("Invalid format❌.");
                scanner.nextLine();
            }
        }while(!choicevalid);
        return choice;
    }

    public int showmanageCategory()
    {
        int choice = 0;
        boolean choicevalid = false;
        System.out.println("🎩 Manage Categories 🎩");
        System.out.println("⿡  Add Category");
        System.out.println("⿢  Delete Category");
        scanner.nextLine();
        do {
            try {
                System.out.print("Enter your choice: ");
                choice = scanner.nextInt();
                if (choice < 1 || choice > 2) {
                    System.out.println("Invalid number❌,enter 1-2.");
                } else
                    choicevalid = true;
            } catch (NumberFormatException e) {
                System.out.println("Invalid format❌.");
                scanner.nextLine();
            }catch (InputMismatchException e){
                System.out.println("Invalid format❌.");
                scanner.nextLine();
            }
        }while(!choicevalid);
        return choice;
    }

    public void addRoom()
    {
        boolean exit = false;
        String roomname="";
        int roomcapacity = 0;
        scanner.nextLine();
        do {
            System.out.println("Enter the room name: ");
            roomname = scanner.nextLine();
            if (roomname.isBlank()) {
                System.out.println("Room name can not be blank❗");
            } else
                exit = true;
        }while(!exit);
        exit = false;
        do{
            try {
                System.out.println("Enter the room capacity: ");
                roomcapacity = scanner.nextInt();
                if (roomcapacity >0)
                    exit = true;
            } catch (NumberFormatException e) {
                System.out.println("Invalid format❌");
            }
        }while(!exit);
        Rooms room = new Rooms(roomname,roomcapacity);
        Database.rooms.add(room);
    }

    public void deleteRoom()
    {
        int counter = 0;
        Rooms other = null;
        boolean exit = false,roomfound = false;
        scanner.nextLine();
        do {
            String roomname = "";
            do {
                System.out.println("Enter the room name to be deleted\uD83D\uDDD1\n: ");
                roomname = scanner.nextLine();
                if (roomname.isBlank()) {
                    System.out.println("Room name can not be blank❗");
                    exit = false;
                }
                else
                    exit = true;
            } while (!exit);
            for (Rooms room : Database.rooms) {
                if (room.getName().equalsIgnoreCase(roomname)){
                    roomfound = true;
                    other = room;
                    break;
                }
            }
            if (roomfound){
                System.out.println("Room has been deleted");
            }
            else {
                System.out.println("Room is not found❌");
                counter++;
            }
            if (counter == 3){
                System.out.println("Would you like to try again? Enter no if not: ");
                if (scanner.nextLine().equalsIgnoreCase("no")){
                    return;
                }
                counter = 0;
            }
        }while(!roomfound);
        Database.rooms.remove(other);
    }

    public boolean addCategory(String name, String description)
    {
//        boolean exit = false;
//        String catname="";
//        String description="";
//        scanner.nextLine();
//        do {
//            System.out.println("Enter the Category name: ");
//            catname = scanner.nextLine();
//            if (catname.isBlank()) {
//                System.out.println("Room name can not be blank❗");
//            } else
//                exit = true;
//        }while(!exit);
//        exit = false;
//        do{
//            System.out.println("Enter the Category description: ");
//            description = scanner.nextLine();
//            if (description.isBlank()) {
//                System.out.println("Description can not be blank❗");
//            } else
//                exit = true;
//        }while(!exit);
        for(Category cat : Database.categories){
            if(cat.getName().equalsIgnoreCase(name)){
                return false;
            }
        }
        Category cat = new Category(name,description);
        Database.categories.add(cat);
        return true;
    }

    public boolean deleteCategory(String name){
//        int counter = 0;
//        Category other = null;
//        boolean exit = false,
        boolean catfound = false;
        ArrayList<Integer> indexes = new ArrayList<>();
//        scanner.nextLine();
//        do {
//            String catname = "";
//            do {
//                System.out.println("Enter the Category name to be deleted: ");
//                catname = scanner.nextLine();
//                if (catname.isBlank()) {
//                    System.out.println("Category name can not be blank❗");
//                }
//                else
//                    exit = true;
//            } while (!exit);
        for (Category cat : Database.categories) {
            if (cat.getName().equalsIgnoreCase(name)) {
                catfound = true;
//                    other = cat;
//                    break;
                Database.categories.remove(cat);
                break;
            }
        }
        if (catfound) {
            for (int i = 0; i < Database.events.size(); i++){
                if(Database.events.get(i).getCategory().equalsIgnoreCase(name)){
                    indexes.add(i);
                    refund(i);
                }
            }
        }
//            if (catfound){
//                System.out.println("Category found✅");
//            }
//            else {
//                System.out.println("Category is not found❌");
//                counter++;
//            }
//            if (counter == 3){
//                System.out.println("Would you like to try again? Enter no if not: ");
//                if (scanner.nextLine().equalsIgnoreCase("no")){
//                    return;
//                }
//                counter = 0;
//            }
//        }while(!catfound);
        indexes.sort(Collections.reverseOrder());
        for(int i : indexes){
            setRoomFree(i);
            Database.events.remove(i);
        }
        return catfound;
    }
    public void setRoomFree(int i){
        for(Rooms room : Database.rooms) {
            if (room.getName().equalsIgnoreCase(Database.events.get(i).getRoom().getName())) {
                room.setFree(Database.events.get(i).getDateTime().getDayOfYear());
            }
            break;
        }
    }

    //Birthdate methods
    public void setBirthdate(String date) {
        birthdate.setDateofbirth(date);
    }
    public void editDateofbirth() {
        birthdate.editDateofbirth();
    }
    public boolean dateformat(String dateofbirth){
        return birthdate.dateFormat(dateofbirth);
    }
    public String getBirthdate() {
        return birthdate.getDateofbirth();
    }

    public boolean deleteOrganizer(String username) {
        Organizer other = null;
        boolean orgfound = false;
//        do {
//            String orgname = "";
//            do {
//                System.out.println("Enter the organizer username to be deleted: ");
//                orgname = scanner.nextLine();
//                if (orgname.isBlank()) {
//                    System.out.println("Organizer username can not be blank❗");
//                }
//                else
//                    exit = true;
//            } while (!exit);
        ArrayList<Integer> indexes = new ArrayList<>();
        for (Organizer org : Database.organizers) {
            if (org.getUsername().equalsIgnoreCase(username)) {
                orgfound = true;
                other = org;
                break;
            }
        }
        if (orgfound) {
            Database.organizers.remove(other);
            for (int i = 0; i < Database.events.size();i++){
                if(Database.events.get(i).getOrganizerUsername().equalsIgnoreCase(username)){
                    indexes.add(i);
                    refund(i);
                }
            }
        }
        indexes.sort(Collections.reverseOrder());
        for(int i : indexes){
            Database.events.remove(i);
        }
        return orgfound;
    }
    public boolean addOrganizer(String username) {
//        boolean usernameCheck = true;
//        System.out.print("Enter the username: ");
//        String userr = scanner.nextLine();
//        if (usernameCheck(userr)) {
//            for (Organizer org : Database.organizers) {
//                if (org.getUsername().equalsIgnoreCase(userr)) {
//                    System.out.println("This username is taken⛔.");
//                    usernameCheck = false;
//                    break;
//                }
//            }
//        }
//        else {
//            usernameCheck = false;
//        }
//        System.out.print("Enter the password: ");
//        String pass = scanner.nextLine();
//        if(usernameCheck && passwordCheck(pass)){
//            System.out.println("Organizer is added successfully✅.");
//            return true;
//        }
//        else
//            return false;
        for (Organizer org : Database.organizers) {
            if (org.getUsername().equalsIgnoreCase(username)) {
                return false;
            }
        }
        return true;
    }

    public boolean deleteEvent(String name){
        for(int i = 0; i < Database.events.size();i++){
            if(Database.events.get(i).getEventName().equalsIgnoreCase(name)){
                refund(i);
                setRoomFree(i);
                Database.events.remove(i);
                return true;
            }
        }
        return false;
    }

    public void showOrganizers(){
        System.out.println("Organizers available: ");
        for(Organizer org : Database.organizers){
            System.out.println(org.getUsername());
        }
    }

    public boolean deleteAttendee(String username){
//        int counter = 0;
        Attendee other = null;
//        boolean exit = false;
//        do {
//            String attname = "";
//            do {
//                System.out.println("Enter the attendee name to be deleted: ");
//                attname = scanner.nextLine();
//                if (attname.isBlank()) {
//                    System.out.println("Attendee name can not be blank❗");
//                }
//                else
//                    exit = true;
//            } while (!exit);
        for (Attendee att : Database.attendees) {
            if (att.getUsername().equalsIgnoreCase(username)) {
                Database.attendees.remove(att);
                System.out.println("Attendee found✅");
                return true;
            }
        }
        System.out.println("Attendee is not found❌");
        return false;
//                counter++;
//            if (counter == 3){
//                System.out.println("Would you like to try again? Enter no if not: ");
//                if (scanner.nextLine().equalsIgnoreCase("no")){
//                    return;
//                }
//                counter = 0;
//            }
//        }while(!attfound);

    }

    public boolean addAttendee(String username){
        for (Attendee att : Database.attendees) {
            if (att.getUsername().equalsIgnoreCase(username)) {
                return false;
            }
        }
        return true;
    }

//    public boolean dateFormat(String date){
//        return birthdate.dateFormat(date);
//    }
//
//    public boolean checkRoom(String name){
//        for (Rooms room : Database.rooms){
//            if (room.getName().)
//        }
//    }

    public void refund(int i){
        for(Attendee att : Database.attendees){
            for(Attendee attEvent : Database.events.get(i).getAttendees()){
                if(att.getUsername().equalsIgnoreCase(attEvent.getUsername())){
                    att.setBalance(att.getBalance()+Database.events.get(i).getTicketPrice());
                    for(Organizer org : Database.organizers){
                        if(org.getUsername().equalsIgnoreCase(Database.events.get(i).getOrganizerUsername())){
                            org.setBalance(org.getBalance()-Database.events.get(i).getTicketPrice());
                            break;
                        }
                    }
                }
            }
        }
    }
    public boolean roomUnique(String rooomName){
        for (Rooms room : Database.rooms){
            if (room.getName().equalsIgnoreCase(rooomName))
                return false;
        }
        return true;
    }

    public boolean addRoom(String roomName,int maxCapacity){
        if(maxCapacity<= 0){
            return false;
        }
        if(roomUnique(roomName)){
            Database.rooms.add(new Rooms(roomName,maxCapacity));
            return true;
        }
        return false;
    }

    public boolean deleteRoom(String roomName) {
        boolean check = false;
        ArrayList<Integer> indexes = new ArrayList<>();
        for (Rooms room : Database.rooms) {
            if (room.getName().equalsIgnoreCase(roomName)) {
                for (int i = 0; i < Database.events.size(); i++) {
                    if (Database.events.get(i).getRoom().getName().equalsIgnoreCase(roomName)) {
                        refund(i);
                        indexes.add(i);
                    }
                }
                Database.rooms.remove(room);
                check = true;
                break;
            }
        }
        indexes.sort(Collections.reverseOrder());
        for(int i : indexes){
            Database.events.remove(i);
        }
        return check;
    }

    public void showAll(){
        System.out.println("Rooms available: ");
        for(Rooms room : Database.rooms)
        {
            System.out.print(room.getName()+",");
        }
        System.out.println("Events available: ");
        {
            for(Events event : Database.events){
                System.out.print(event.getEventName()+",");
            }
        }
        System.out.println("Attendees: ");
        for(Attendee att : Database.attendees) {
            System.out.print(att.getUsername() + ",");
        }}
}