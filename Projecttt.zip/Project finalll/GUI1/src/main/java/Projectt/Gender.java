package Projectt;

public enum Gender {
    MALE,FEMALE;
}
