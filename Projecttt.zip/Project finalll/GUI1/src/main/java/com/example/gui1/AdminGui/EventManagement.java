package com.example.gui1.AdminGui;

import Projectt.Admin;
import Projectt.Category;
import Projectt.Database;
import Projectt.Events;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.net.URL;

public class EventManagement {
    private Stage primaryStage;
    private boolean addShow, deleteShow, showAllShow;
    private VBox inputBox = new VBox(10);
    private TextField eventName = new TextField();
    private PasswordField password = new PasswordField();
    private TextField date = new TextField();
    private Admin admin = null;

    public EventManagement(Stage primaryStage, Admin admin) {
        this.primaryStage = primaryStage;
        this.admin = admin;
    }

    public void show() {
        VBox orgVbox = new VBox(20);
        orgVbox.setAlignment(Pos.TOP_CENTER);
        orgVbox.setPadding(new Insets(25));
        orgVbox.setStyle("-fx-background-color: linear-gradient(to bottom right, #1A1A2E, #4A148C);");
        primaryStage.setTitle("Events");

        Label title = new Label("Events Management");
        title.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: white; -fx-font-family: Arial;");

        Button showAllButton = buttonStyle("Show All");
        Button deleteEventButton = buttonStyle("Delete Event");
        Button backButton = buttonStyle("Back to Dashboard");

        showAllButton.setOnAction(e -> showEvents());
        deleteEventButton.setOnAction(e -> deleteEvent());
        backButton.setOnAction(e -> new AdminDashboard(primaryStage, admin).show());

        textStyle(eventName);
        textStyle(date);

        inputBox.setAlignment(Pos.CENTER);
        inputBox.setPadding(new Insets(15));
        inputBox.setVisible(false);
        inputBox.setManaged(false);

        orgVbox.getChildren().addAll(title, showAllButton, deleteEventButton, inputBox, backButton);

        Scene scene = new Scene(orgVbox, 400, 500);
        URL cssUrl = getClass().getResource("/com/example/gui1/buttonStyle.css");
        if (cssUrl != null) {
            scene.getStylesheets().add(cssUrl.toExternalForm());
        } else {
            System.err.println("CSS file not found!");
        }
        primaryStage.setScene(scene);
    }

    private Button buttonStyle(String text) {
        Button button = new Button(text);
        button.getStyleClass().add("button");
        return button;
    }
//
//    private void addEvent() {
//        if (addShow) {
//            inputBox.getChildren().clear();
//            inputBox.setVisible(false);
//            inputBox.setManaged(false);
//            addShow = false;
//            return;
//        }
//        if (deleteShow) {
//            inputBox.getChildren().clear();
//            deleteShow = false;
//        }
//        if (showAllShow) {
//            inputBox.getChildren().clear();
//            showAllShow = false;
//        }
//
//        inputBox.getChildren().clear();
//
//        Label title = new Label("Add New Event");
//        title.setStyle("-fx-font-size: 16px; -fx-text-fill: white; -fx-font-family: Arial;");
//
//        Label nameLabel = new Label("Event Name:");
//        nameLabel.setStyle("-fx-text-fill: white; -fx-font-family: Arial;");
//
//        Label dateLabel = new Label("Date (dd/mm/yyyy):");
//        dateLabel.setStyle("-fx-text-fill: white; -fx-font-family: Arial;");
//
//        Button submitButton = buttonStyle("Submit");
//        submitButton.setOnAction(e -> {
//            System.out.println("Event Name: " + eventName.getText());
//            System.out.println("Date: " + date.getText());
//            inputBox.setVisible(false);
//            inputBox.setManaged(false);
//            inputBox.getChildren().clear();
//            addShow = false;
//        });
//
//        inputBox.getChildren().addAll(title, nameLabel, eventName, dateLabel, date, submitButton);
//        inputBox.setVisible(true);
//        inputBox.setManaged(true);
//        addShow = true;
//    }

    private void deleteEvent() {
        if (deleteShow) {
            inputBox.getChildren().clear();
            inputBox.setVisible(false);
            inputBox.setManaged(false);
            deleteShow = false;
            return;
        }
        if (addShow) {
            inputBox.getChildren().clear();
            addShow = false;
        }
        if (showAllShow) {
            inputBox.getChildren().clear();
            showAllShow = false;
        }

        inputBox.getChildren().clear();

        Label title = new Label("Delete Event");
        title.setStyle("-fx-font-size: 16px; -fx-text-fill: white; -fx-font-family: Arial;");

        Label eventNameLabel = new Label("Event Name:");
        eventNameLabel.setStyle("-fx-text-fill: white; -fx-font-family: Arial;");

        Button submitButton = buttonStyle("Delete");
        submitButton.setOnAction(e -> {

            inputBox.getChildren().removeIf(node -> node instanceof Label && "alert".equals(node.getId()));
            String nameInput = eventName.getText();
            if (nameInput.isBlank())
                return;
            if(admin.deleteEvent(nameInput)){
                Label success = new Label("Event removed successfully!");
                success.setStyle("-fx-text-fill: lightgreen; -fx-font-family: Arial;");
                success.setId("alert"); // for later removal
                inputBox.getChildren().add(success);
            }
            else {
                Label invalid = new Label("Incorrect Event name!");
                invalid.setStyle("-fx-text-fill: red; -fx-font-family: Arial;");
                invalid.setId("alert");
                inputBox.getChildren().add(invalid);
            }
            eventName.clear();

        });

        inputBox.getChildren().addAll(title, eventNameLabel, eventName, submitButton);
        inputBox.setVisible(true);
        inputBox.setManaged(true);
        deleteShow = true;
    }

    private void showEvents() {
        if (showAllShow) {
            inputBox.getChildren().clear();
            inputBox.setVisible(false);
            inputBox.setManaged(false);
            showAllShow = false;
            return;
        }
        if (addShow) {
            inputBox.getChildren().clear();
            addShow = false;
        }
        if (deleteShow) {
            inputBox.getChildren().clear();
            deleteShow = false;
        }

        inputBox.getChildren().clear();

        Label title = new Label("Events Available:");
        title.setStyle("-fx-font-size: 16px; -fx-text-fill: white; -fx-font-family: Arial;");
        inputBox.getChildren().add(title);

        for (Category cat : Database.categories) {
            Label catLabel = new Label(cat.getName());
            catLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: white; -fx-font-family: Arial;");
            inputBox.getChildren().add(catLabel);

            for (Events event : Database.events) {
                if (event.getCategory().equals(cat.getName())) {
                    String formattedDate = event.getDateTime().toLocalDate().format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                    Label eventLabel = new Label("- " + event.getEventName() + "\t" + formattedDate);
                    eventLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: white; -fx-font-family: Arial;");
                    inputBox.getChildren().add(eventLabel);
                }
            }
        }

        inputBox.setVisible(true);
        inputBox.setManaged(true);
        showAllShow = true;
    }


    private void textStyle(TextField textField) {
        textField.setStyle("-fx-background-color: rgba(255,255,255,0.2); " +
                "-fx-text-fill: white; -fx-font-family: Arial; " +
                "-fx-prompt-text-fill: #aaa; -fx-background-radius: 5;");
        textField.setMaxWidth(250);
    }
}
